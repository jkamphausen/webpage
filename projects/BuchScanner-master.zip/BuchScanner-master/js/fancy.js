$( document ).ready(function() {
	$('[data-toggle="tooltip"]').tooltip(); 	//Opt-in tooltips
	$('[data-toggle="popover"]').popover();	 	//Opt-in tooltips
});

/*
 *	Created by Julian Kamphausen, 2016 Cologne
 */