# BuchScanner
BuchScanner is a small tool - developed to fetch data from Google Books in order to feed an instance of WebLibrarian. Its a student assistend project.
