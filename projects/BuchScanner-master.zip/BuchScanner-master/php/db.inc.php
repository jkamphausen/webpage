<?php 
	$server   = "localhost";
	$user     = "root";
	$pw       = "";
	$dbname   = "wp_hki";
	$tabname  = "wp_weblib_collection";

/*
 *	Created by Julian Kamphausen, 2016 Cologne
 */
  







